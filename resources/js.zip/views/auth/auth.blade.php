@extends("templates.public")
@section("content")


<section style="height:500px;width:100%;max-height:400px;overflow:auto">
	<div style="width:100%">
		<div style="width:50%;min-height:400px;float:left;border-right:1px solid #ccc">
			<br/><br/>
			<h3 align="center" style="font-family:Georgia;font-size:18px">Existing Customer</h3>
			<form method="post" action="{{URL::to('auth')}}">
			<table align="center" style="margin-left:70px;max-width:300px;margin-top:30px;">
				<tr>
					<td colspan="2">Email Address</td>
				</tr>
				<tr>
					<td colspan="2">
						<input type="email" name="email" style="padding:10px;" size="35">
					</td>
				</tr>
				<input type="hidden" name="_token" value="{{csrf_token()}}">
				<tr>
					<td colspan="2">Password</td>
				</tr>
				<tr>
					<td colspan="2"><input type="password" name="password" style="padding:10px" size="35"></td>
				</tr>
				<tr>
					<td><a href="#" style="text-decoration:underline">Forgot Password</a></td>
					<td align="right">
						<input type="submit" value="Log In" style="display:inline-block;padding:10px 30px;border:1px solid #ccc;color:white;background-color:maroon">
					</td>
				</tr>
				<tr>
					<td colspan="2" style="color:red">
					<br/>
						@if(isset($message))

						{{$message}}

						@endif

					</td>
				</tr>
			</table>
		</form>
		</div>
		<div style="width:50%;float:left;background-color:#f0f8ff;min-height:400px">
			<br/><br/>
			<h3 align="center" style="font-family:Georgia;font-size:18px">Register Now</h3>
			<form method="post" action="{{URL::to('/createProfile')}}">
			<table align="center" style="margin-left:70px;max-width:300px;margin-top:30px;background-color:#f0f8ff">
				<input type="hidden" name="_token" value="{{csrf_token()}}">
				<tr>
					<td colspan="2">Email Address</td>
				</tr>
				<tr>
					<td colspan="2">
						<input type="email" name="email" style="padding:10px;" size="35" required>
					</td>
				</tr>
				<tr>
					<td colspan="2">Password</td>
				</tr>
				<tr>
					<td colspan="2">
						<input type="password" name="password" style="padding:10px;" size="35" required>
					</td>
				</tr>
				<tr>
					<td colspan="2">Repeat Password</td>
				</tr>
				<tr>
					<td colspan="2">
						<input type="password" name="confirmpassword" style="padding:10px;" size="35" required>
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<input type="checkbox" name="confirmation1ForSignup"> I confirm that I have read and accept this Privacy Policy.
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<input type="submit" value="Next" style="display:inline-block;padding:10px 30px;border:1px solid #ccc;color:white;background-color:maroon">
					</td>
				</tr>
				<tr>
					<td colspan="2" style="color:red">
						@if(isset($errorMessage))

							{{$errorMessage}}

						@endif
					</td>
				</tr>
			</table>
		</form>

		</div>
	
	</div>


</section>

@endsection