@extends("admin.templates.contacts")
@section("contacts_content")
<br/><br/>
<div class="container">
    <h4>Welcome to Contact Management System please use above sub menu to use control contacts</h4>
</div>
@endsection