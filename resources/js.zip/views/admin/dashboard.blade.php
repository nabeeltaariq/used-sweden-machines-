@extends("admin.templates.admin")
@section('content')
<br/><br/>
<div class="container">
    <h3>You are on dashboard page Click on any above menu control to manage website</h3>
</div>
@endsection