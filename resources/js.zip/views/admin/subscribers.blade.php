@extends("admin.templates.contacts")
@section("contacts_content")
<h3>All Subscribers</h3>
<hr/>
<table class="table table-brodered table-striped table-sm">
    <thead>
        <tr>
            <th>ID</th>
            <th>Email</th>
            <th>Country</th>
            <th>Language</th>
        </tr>
    </thead>
    <tbody>
        @foreach($subscribers as $sub)

            <tr>
            <td>{{$sub->id}}</td>
            <td>{{$sub->email_add}}</td>
            <td>{{$sub->country}}</td>
            <td>{{$sub->selected_language}}</td>
            </tr>

        @endforeach
    </tbody>
</table>
@endsection