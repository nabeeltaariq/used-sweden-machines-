@extends("admin.templates.contacts")
@section("contacts_content")
<br/>
<h3>Edit Country <sup>{{$country->country_name}}</sup></h3>
<hr/>
@if(isset($message))

<div class="alert alert-success">
    {{$message}}
</div>

@endif
<form method="post" enctype="multipart/form-data" action="">
    <label>
        Country Name
        <input type="text" name="countryName" id="countryName" class="form-control" value="{{$country->country_name}}" required>
    </label>
    <label>
        Country Code
        <input type="text" name="countryCode" id="countryCode" class="form-control" value="{{$country->country_code}}" required>
    </label>
    <label>
        Flag
        <input type="file" name="flag" id="flag">
        <img src="{{URL::to('/storage/app/cms/countries/')}}/{{$country->picUrl}}" class="img-thumbnail" style="max-width:150px"/>
    </label>
    <input type="submit" value="Save Changes" class="btn btn-danger btn-block">
    <input type="hidden" name="_token" value="{{csrf_token()}}">
</form>

@endsection