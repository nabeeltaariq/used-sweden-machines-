@extends("admin.templates.contacts")
@section("contacts_content")
<form action="" method="post">
    Quick Add Designation
    <input type="hidden" name="_token" value="{{csrf_token()}}">
    <input type="text" name="designationName" id="designationName"/>
    <input type="submit" value="Save" class="btn btn-primary btn-sm">
</form>
<br/>
@if(isset($message))

<div class="alert alert-success">
    {{$message}}
</div>

@endif
<div class="alert alert-success" id="alert" style="display:none">
    Designation Updated and <strong><span id="count">0</span></strong> records affected
</div>
     <div class="row">
         <div class="col-lg-6 col-md-6">
            
            <table class="table table-bordered table-sm">
                <thead>
                    <tr>
                        <th>S#</th>
                        <th>Designation</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    @for($i = 0;$i<count($designations)/2;$i++)

                        <tr>
                        <td>{{$i+1}}</td>
                        <td class="designationName">{{$designations[$i]->name}}</td>
                        <td><a href="#" id="{{$designations[$i]->designationId}}" class="editButton">Edit</a></td>
                        </tr>

                    @endfor
                </tbody>
            </table>
         </div>
         <div class="col-lg-6 col-md-6">
            <table class="table table-bordered table-sm">
                <thead>
                    <tr>
                        <th>S#</th>
                        <th>Designation</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    @for($i = count($designations)/2;$i<count($designations);$i++)

                        <tr>
                        <td>{{$i+1}}</td>
                        <td class="designationName">{{$designations[$i]->name}}</td>
                            <td><a href="" id="{{$designations[$i]->designationId}}" class="editButton">Edit</a></td>
                        </tr>

                    @endfor
                </tbody>
            </table>
        </div>
        
     </div>
<script>

    let designationIdToEdit = null;
    $(document).ready(function(){

        setTimeout(() => {
            $(".alert").hide();
        }, 5000);

    });
    $(".editButton").on("click",function(){

        $(this).parent().parent().children()[1].setAttribute("contenteditable","true");
        $(this).parent().parent().children()[1].focus();
        $(this).parent().parent().children()[1].setAttribute("bgcolor","white");
        designationIdToEdit = $(this).attr("id");
        
        return false;

    });

    $(".designationName").on("focusout",function(){

        $(this).removeAttr("contenteditable");
        $(this).removeAttr("bgcolor");

        const data = confirm("Are you sure you want to rename? this will effect all the records in cms");
        if(data == true){
            $.ajax({
                url:"{{URL::to('admin/contacts/designations/update')}}",
                method:"POST",
                data:{id:designationIdToEdit,"newName":$(this).html(),_token: '{{csrf_token()}}'},
                success:data => 
                {
                    $("#alert").show();
                    $("#count").html(data);
                    setTimeout(() => {
                            $("#alert").hide();
                    }, 3000);
                }
            })
        }
    
    
    });

</script>
@endsection