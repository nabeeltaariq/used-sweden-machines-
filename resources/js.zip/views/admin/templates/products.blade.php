@extends("admin.templates.admin")
@section("content")
    <ul class="productMenu">
    <li><a href="{{URL::to('/admin/products/catagories')}}">Manage Catagories</a></li>
    <li><a href="{{URL::to('admin/products/addCategory')}}">Add Category</a></li>
    <li><a href="{{URL::to('/admin/products/new')}}">Add Product</a></li>
    <li><a href="{{URL::to('admin/products')}}">Manage Products</a></li>
    <li><a href="{{URL::to('admin/products/uploadedProducts')}}">Uploaded Products</a></li>
    <li><a href="{{URL::to('admin/products/stockReport')}}">Stock Reports</a></li>
    </ul>
   <style>
       ul.productMenu{
           list-style-type:none;
           padding-left:30px;
           width:100%;
           background-color:#ccc;
           font-size:12px;
           font-weight:bolder;
           position:fixed;
           z-index:100;

       }
       ul.productMenu li{
           display:inline-block;
       }

       ul.productMenu li a{
           display:inline-block;
           padding:0px 10px;
           color:black;
           border-right:1px solid gray;
       }

   </style>
   <br/>
    @yield("products_content")

@endsection
