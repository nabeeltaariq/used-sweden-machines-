<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>USM-Admin</title>
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<script src="https://kit.fontawesome.com/6ba88d1a21.js" crossorigin="anonymous"></script>
<script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.7.8/angular.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.19.2/axios.js"></script>
</head>
<body>
    <div id="head" style="position:fixed;top:0;left:0;right:0;z-index:500">
		<div style="width:100%;height:80px;background:url({{URL::to('/public/imgs/banner1.png')}}) no-repeat;background-size:cover">
			<div style="float:left;margin-left:30px;height:80px;width:50%;">
				<img src="{{URL::to('/public/imgs/logo.png')}}" width="111.33px" height="80px">
			</div>
			<div style="float:right;height:80px;width:45%;">
				<p align="right" style="padding-bottom:0px;margin-top:9px;font-size:11px;margin-right:30px">
				<span style="color:#034375;font-weight:bold;font-size: 17px;">Used Sweden Machines</span><br>
				D.O.H.S 290, Phase 1 Gujranwala, Pakistan
				<br>
				Company Registration No: 4015134-4<br>
				Tel.: +92(321)7415373<br>
				E-Mail: <a href="#" style="text-decoration:underline;color:blue">info@usedsweedenmachines.com</a>
				</p><p align="right" style="padding-bottom:0">

				</p>
			<p></p>

			</div>

		</div>






		<div id="menus_wrapper" style="padding:0px">
			<div id="main_menu">

				<ul>
                	                	                	<li>
					<a href="{{URL::to('/admin')}}">
					<span><span>Home</span></span></a></li>


					<!--<li><a href="siteoptions.php" >
                    <span><span>Website Configuration</span></span></a></li>-->
					<!--<li><a href="users.php" >
                    <span><span>Mailer</span></span></a></li>-->
                    <li><a href="{{URL::to('admin/products')}}">
                    <span><span>Products</span></span></a></li>
                    <li><a href="{{URL::to('admin/pages')}}">
                    <span><span>Pages</span></span></a></li>
                    <li><a href="{{URL::to('admin/news')}}">
                    <span><span>News</span></span></a></li>
															<!-- <li>
                    <a href="https://www.usedswedenmachines.com/admin/newsletter/newsletter.php"  >
                    <span><span>Newsletter</span></span></a></li> -->
                                                            {{-- <li>
                    <a href="">
                    <span><span>Stock Lists</span></span></a></li> --}}
                                                               <li>
                                                               <a href="{{URL::to('admin/spareParts')}}">
                    <span><span>Spare Parts</span></span></a></li>


                    <li>
                    <a href="{{URL::to('admin/contacts')}}">
                     <span><span>CMS</span></span></a></li>
                    {{--
                    <li>
                    <a href="">
                    <span><span>HCMS</span></span></a></li>
					<li>
                    <a href="">
                    <span><span>E-CMS</span></span></a></li>






                     <li>
                    <a href="https://www.usedswedenmachines.com/admin/data/index.php">
                    <span><span>DMS</span></span></a></li>
                                                     <li>
                    <a href="https://www.usedswedenmachines.com/admin/ebusiness/index.php">
                    <span><span>E-Business</span></span></a></li>
                                                     <li>
                    <a href="https://www.usedswedenmachines.com/admin/accounts/index.php">
                    <span><span>User Accounts</span></span></a></li> --}}
                                                       <li style="float:right;">
                                                        <div class="btn-group">
                                                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                                               {{Request::session()->get("activeUser")->username}}
                                                            </a>
                                                            <div class="dropdown-menu">
                                                                <a href="{{URL::to('/')}}" class="dropdown-item" target="_blank">Visit Site</a>
                                                                <a class="dropdown-item" href="#">Change Password</a>
                                                                <a class="dropdown-item" href="{{URL::to('/admin/logout')}}">Logout</a>
                                                            </div>
                                                          </div>
                    </li>


				</ul>
			</div>



		</div>
    </div>
    <style>
        #menus_wrapper{
            position: fixed;
            top: 81px;
            background-color:#034375;
            left:0;
            right:0;
            z-index:500;
        }

        #menus_wrapper #main_menu ul{
            width:100%;
            list-style-type:none;
            margin:0;
            padding-left:30px;
        }

        #menus_wrapper #main_menu ul li{
            display:inline-block;
        }

        #menus_wrapper #main_menu ul li a{
            display:inline-block;
            padding:12px 10px;
            color:white;
            text-decoration:none;
            font-weight:bolder;
            font-family:arial;

            border-right:1px solid #cccccc3d;

        font-size: 14px;
        }



        #menus_wrapper #main_menu ul li a:hover{
            background-color:#ccc;
            color:black;
        }

        #menus_wrapper #main_menu ul li a.dropdown-item{
            color:black;
        }

        body{
            background-color:#eee;
        }
        label{
            width:100%;
        }
    </style>
    <div class="" style="margin-top:126px">
    @yield("content")
    </div>

<script>
$(document).ready( function () {
    $('#myTable').DataTable();


                // Replace the <textarea id="editor1"> with a CKEditor
                // instance, using default configuration.
                CKEDITOR.replace( 'description' );

} );
</script>
</body>
</html>
