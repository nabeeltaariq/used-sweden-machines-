@extends("admin.templates.admin")
@section("content")
    <ul class="productMenu">
    <li><a href="{{URL::to('admin/spareParts')}}">Manage Machines</a></li>
    <li><a href="{{URL::to('admin/spareParts/categories')}}">Manage Categories</a></li>
    <li><a href="{{URL::to('admin/spareParts/home')}}">Manage Spare Parts</a></li>
    </ul>
   <style>
       ul.productMenu{
           list-style-type:none;
           padding-left:30px;
           width:100%;
           background-color:#ccc;
           font-size:12px;
           font-weight:bolder;
           position:fixed;
           z-index:100;
           
       }
       ul.productMenu li{
           display:inline-block;
       }

       ul.productMenu li a{
           display:inline-block;
           padding:0px 10px;
           color:black;
           border-right:1px solid gray;
       }
   
   </style>
   <br/>
   <div class="container-fluid">
    @yield("parts_content")
    </div>
@endsection