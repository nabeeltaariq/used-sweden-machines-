@extends("admin.templates.admin")
@section("content")
    <ul class="productMenu">
    <li><a href="{{URL::to('admin/news')}}">Manage News</a></li>
    <li><a href="{{URL::to('admin/news/new')}}">Add News</a></li>
    <li><a href="{{URL::to('admin/news/events/browse')}}">Manage Events</a></li>
    <li><a href="{{URL::to('admin/news/events/new')}}">Add Events</a></li>
    <li><a href="{{URL::to('admin/news/testimonials')}}">Manage Testimonials</a></li>
    <li><a href="{{URL::to('admin/news/testimonials/new')}}">Add Testimonial</a></li>
    <li><a href="{{URL::to('admin/news/references')}}">Manage References</a></li>
    <li><a href="{{URL::to('admin/news/references/new')}}">Add References</a></li>
    </ul>
   <style>
       ul.productMenu{
           list-style-type:none;
           padding-left:30px;
           width:100%;
           background-color:#ccc;
           font-size:12px;
           font-weight:bolder;
           position:fixed;
           z-index:100;
           
       }
       ul.productMenu li{
           display:inline-block;
       }

       ul.productMenu li a{
           display:inline-block;
           padding:0px 10px;
           color:black;
           border-right:1px solid gray;
       }
   
   </style>
   <br/>
   <div class="container-fluid">
    @yield("news_content")
    </div>
@endsection