@extends("admin.templates.admin")
@section("content")
    <ul class="productMenu">
    <li><a href="{{URL::to('admin/contacts/head')}}">Contacts Head</a></li>
    <li><a href="{{URL::to('admin/contacts/subscribers')}}">Subscribed Email</a></li>
    <li><a href="{{URL::to('admin/contacts/new')}}">Contacts</a></li>
        <li><a href="{{URL::to('admin/contacts/designations')}}">Designation</a></li>
    <li><a href="{{URL::to('admin/contacts/services')}}">Products/Services</a></li>
    <li><a href="{{URL::to('admin/contacts/countries')}}">Countries</a></li>
    <li><a href="{{URL::to('admin/contacts/find')}}">Find</a></li>
    </ul>
   <style>
       ul.productMenu{
           list-style-type:none;
           padding-left:30px;
           width:100%;
           background-color:#ccc;
           font-size:12px;
           font-weight:bolder;
           position:fixed;
           z-index:100;
           
       }
       ul.productMenu li{
           display:inline-block;
       }

       ul.productMenu li a{
           display:inline-block;
           padding:0px 10px;
           color:black;
           border-right:1px solid gray;
       }
   
   </style>
   <br/>
   <div class="container-fluid">
    @yield("contacts_content")
    </div>
@endsection