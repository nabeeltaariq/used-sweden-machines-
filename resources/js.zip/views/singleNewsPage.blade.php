@extends("templates.public")
@section("sharing")

<meta property="og:url" content="https://usedswedenmachines.com/news/{{$news->id}}" />
<meta property="og:type" content="article" />
<meta property="og:title" content="{{$news->news_title}}" />
<meta property="og:description" content="{{$news->news_des}}" />
<meta property="og:image" content="{{URL::to('public/img/logo.png')}}" />

@endsection
@section("content")

<div style="font-family:arial;font-size:11px">

   <a href="{{URL::to('/')}}" style="">Home</a>&nbsp;»&nbsp;<a href="{{URL::to('/news')}}">News</a>

    <style>

        a{

            color:#034375;

        }

    </style>    

</div>

   <div class="row">

        <div class="col-xl-6 col-lg-6 col-md-6">

            @php

                if($news->image == null){

                    $url = URL::to('public/imgs/newsletter-icon.png');

                }else{

                    $url = URL::to("/storage/app/products/$news->image");

                }

            @endphp

            <img class="mainImage" src="{{$url}}" alt="" style="max-height: 310px;
            border: 2px solid #034375;
            max-width: 400px;
            min-width: 300px;">

            <div style="margin:10px 30px 0px 0px;">

                {{-- <div class="owl-carousel owl-theme">

                    @php

                    $allThumbs = App\Thumbs::where("org_id",$product->id)->get();    



                    @endphp

                    @foreach($allThumbs as $thumb)

                    <div class="item">

                    <img class="thumb" src="{{URL::to('/storage/app/products/')}}/{{$thumb->file_name}}" alt="" style="min-height:75px;max-height:75px;border:2px solid blue;cursor:pointer">

                    </div>

                    @endforeach

                    

                </div> --}}

               {{-- @if(count($allThumbs) >= 1)

                *drag the images to scroll

                @endif --}}

            </div>

        </div>

        <div class="col-xl-6 col-lg-6 col-md-6">

            <div style="background-color: #ddeef1;
            min-height: 310px;
            max-height: 310px;
            
            overflow: auto;
            font-size: 12px;
            border: 2px solid #808080a6;">

                <strong>{{$news->news_title}}</strong><Br/>

                <strong>News #: </strong>&nbsp;&nbsp;&nbsp;{{$news->id}}<br/>

                <strong>News Date</strong>&nbsp;&nbsp;&nbsp;

                {{$news->news_date}}<br/>

                <strong>Description: </strong><br/>
                <?php
                    echo html_entity_decode($news->news_des);
                ?>
            </div>

            <div>

                <ul class="shareButtons" style="margin-top: -4px;">
                    <li><a href="http://www.facebook.com/sharer/sharer.php?u=https://www.usedswedenmachines.com/news/{{$news->id}}" target="_blank" style="color:#024374"><i class="fab fa-facebook-square"></i></a></li>
                    <li><a href="https://www.linkedin.com/shareArticle?mini=true&url=https://www.usedswedenmachines.com/news/{{$news->id}}&title={{$news->news_title}}&summary=Used Sweden Machines News&source=USM" style="color: #017bb5" target="_blank"><i class="fab fa-linkedin"></i></a></li>
                    <li><a href="whatsapp://send?text=https://www.usedswedenmachines.com/news/{{$news->id}}" target="_blank" style="color:#65bc54"><i class="fab fa-whatsapp-square"></i></a></li>
                <li><a href="mailto:?subject={{$news->news_title}}Machine-Used%20Sweden%20Machines News&body=To%20Get%20Information%20About%20This%20News,%20Please%20Visit%20https://www.usedswedenmachines.com/news/{{$news->id}}" target="_blank" style="color:#c15b53"><img src="{{URL::to('/public/imgs/email.png')}}" alt="" style="heigt:25px;margin-top:-8px;max-height:25px;max-width:25.17px;min-width:25.17px;width:25.17px"></a></li>
                   
                <!-- <li><a href="" target="_blank" style="color:maroon">
                <img src="{{URL::to('/public/imgs/pdf.png')}}" style="    height: 25px;
                margin-top: -08px;" alt="image not found">
             </a></li> -->
                </ul>

            </div>

            <br/>

            <div style="margin-left:110px">

               

               

                 

                <a href="{{URL::to('/news')}}" class="btn-theme">All News</a>

                @if($news->Next() != null)

                <a href="{{URL::to('/news/')}}/{{$news->Next()->id}}" class="btn-theme">Next News</a>

                @endif

            </div>

        </div>

    </div>

<style>

.shareButtons{
    list-style-type:none;
    margin:0;
    padding:0;
}

.shareButtons li{
    display:inline-block;
}

.shareButtons li a{
    display: inline-block;
    font-size: 30px;
    /* margin-right: 3px; */
    margin-right: -2px;
}

.btn-theme{

  

    display: inline-block;

    padding: 5px 20px;

    background-color: #034375;

    color: white;

    border-radius: 5px;

    box-shadow: 2px 2px 2px #ccc;

    margin: 0px 10px 30px 0px;



}



.btn-theme:hover{

    color:white;

    text-decoration:none;

}

</style>

<script>

$('.owl-carousel').owlCarousel({

    loop:false,

    margin:4,

    nav:true,

    responsive:{

        0:{

            items:5

        },

        600:{

            items:5

        },

        1000:{

            items:5

        }

    }

})



$(".thumb").on("click",function(){



   let src = $(this).attr("src");

    $(".mainImage").attr("src",src);

});

</script>

@endsection