@extends("templates.public")
@section("content")
<div style="max-height: 465px;
    overflow: auto;
    font-family: arial;
    font-size: 13px;
    box-sizing:border-box;
    padding-top:13px;
    color: #444;
    line-height:20px;">
@php
        $data = App\Page::find(4)->page_contents;
        $data = html_entity_decode($data);
        echo $data;


@endphp
</div>
<style>
 table{
         background-color:#f3f9fa;
         width:100%;
 }
 p{
         margin:0;
 }
 
</style>


@endsection

