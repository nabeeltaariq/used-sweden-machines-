@extends("templates.public")
@section("content")

<div align="center">
    <font face="Verdana, Geneva, sans-serif" size="1" style="font-size:10px;">So that our emails do not end up in your SPAM folder, please add our <a href="mailto:newsletter@usedswedenmachines.com">E-Mail-Adress</a> to your address book.</font>
</div>
<div class='div_style' align='center'>
<hr />
@php
    echo html_entity_decode($newsLetter->temp_design)
@endphp
</div>
<style>
    .div_style
    {
    
    border: 5px solid;
    border-radius: 10px;
    border-color: #034375;
    
    padding: 5px 5px 5px 5px; 
    }
    </style>

@endsection