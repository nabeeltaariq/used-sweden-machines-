@extends("templates.public")

@section("content")

<div style="font-family:arial;font-size:11px">

    <a href="{{URL::to('/')}}" style="">Home</a>&nbsp;»&nbsp;<span>Tetra Pak Machines Spare Parts</span></span>

     <style>

         a{

             color:#034375;

         }

     </style>    

 </div>

<div class="row">

    <div class="col-lg-3 col-md-3">

    <form action="{{URL::to('/all-spare-parts')}}" method="get">

        <ul style="padding:0px">

            

            <li class="aside-submenu" id="web">

              <a id="web" class="tag">Select Your Machine Part</a> 

               <select class="show-aside-ul menu12" id="machine_id" required style="width: 100%;padding: 2px;" name="machineId" required="">

                  <option value="">Select Machine</option>



                @foreach($machines as $machine)



               <option value="{{$machine->id}}">{{$machine->title}}</option>



                @endforeach

               </select>

            </li>

            <li class="aside-submenu">

              

              <select class="show-aside-ul" required style="width: 100%;padding: 2px;" name="cat_id" id="category_id" required="">

                <option value="">Select Part Category</option>

                           </select>

            </li>

            <li class="aside-submenu">

      

               <select class="show-aside-ul"  required style="width: 100%;padding: 2px;" id="sub_category" name="subcat_id" required="">

                  <option value="">Select Type</option>

                  

               </select>

            </li>

    

            <li style="background:white; float:right;">

            

           

              <input name="search_part" type="submit" class="news_btn" id="Submit" style="background: #034375;width: 100px;

                height: 28px;

                color: #fff;

                cursor: pointer;

                border-radius: 5px;

                box-shadow: 0 0 20px 0 rgba(0,0,0,.3);" value="Search">

            

            </li>

         </ul>

        </form>

    </div>

    <div class="col-lg-9 col-md-9" style="    padding: 0px;
    margin-left: -15px;">

        <ul class="machinesView">

            @foreach($machines as $machine)



        <li>

        <a href="{{URL::to('spare-parts/categories')}}/{{$machine->id}}">

            <img style="width:146px;height:100px" src="{{URL::to('/storage/app/products/') . '/' . $machine->image}}" alt=""><br/><strong>{{$machine->title}}</strong></li>

            </a>

            @endforeach

        </ul>

    </div>

</div>



<style>

    ul{

        list-style-type:none;

    }



    .tag{

        display: block;

        background: none repeat scroll 0 0 #999;

        color: white;

        padding: 5px;

        margin: 5px 0px 2px;

        font-family: "Open Sans",Arial,sans-serif;

        font-size:13px;

    }



    .tag:hover{

        color:white;

        text-decoration:none;

        cursor:default;

    }



    ul.machinesView{

      

    }



    ul.machinesView li{

        width:25%;

        height:140px;

        float:left;

        

    }

    ul.machinesView li img{

        width:90%;

        height:140px;

        max-width:100%;

        max-height:180px;

    }



    ul.machinesView li a{

        color:black;

    }



    ul.machinesView li a:hover{

        text-decoration:none;

    }



    ul.machinesView li strong{

        font-weight:bolder;

        font-size:14px;

    }

</style>

<script>

    $("#machine_id").on("change",function(){

      let machineId = $(this).val();

      $.ajax({

          url:"{{URL::to('/api/getPartsCategories')}}/" + machineId,

          method:"GET",

          success:function(response){

              let categories = response;

              $("#category_id").html("<option value=''>Select Categories</option>");

              categories.map(category => {

                  $("#category_id").append("<option value='"+category.id+"'>"+category.title+"</option>");

              })



          }

      })

    });



    $("#category_id").on("change",function(){



        let category_id = $(this).val();

        $.ajax({

            url:"{{URL::to('/api/getSubCategory')}}/" + category_id,

            method:"GET",

            success:function(response){

               $("#sub_category").html("<option value=''>Select Sub Category</option>");

               response.map(data => {

                   $("#sub_category").append("<option value='"+data.id+"'>"+data.title+"</option>")

               })

            }

        })



    });



</script>

@endsection