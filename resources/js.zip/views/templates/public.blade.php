<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>USED SWEDEN MACHINES</title>
    @yield("sharing")
    <link rel="shortcut icon" href="{{URL::to('/public/imgs/favicon.png')}}">
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<link rel="stylesheet" href="{{URL::to('/public/css/jquery.mThumbnailScroller.css')}}">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<script src="{{URL::to('/public/js/angular.js')}}"></script>
<script src="https://kit.fontawesome.com/6ba88d1a21.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="{{URL::to('/public/css/owl.carousel.min.css')}}">
<link rel="stylesheet" href="{{URL::to('/public/css/owl.theme.default.min.css')}}">
<script src="{{URL::to('/public/js/owl.carousel.js')}}"></script>
<link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="{{URL::to('/public/js/jquery.mThumbnailScroller.min.js')}}"></script>
<script src="https://www.google.com/recaptcha/api.js?render=6LeZq9gUAAAAAEG6mWFXj3o_k0h35O8otcNK7ftL"></script>
</head>
<body>
    <div class="page" style="visibility:hidden">
        <div class="MainContainer">
            <span style="color:red"><strong style="font-weight:bold;font-size:14px">Hotline: <a href="tel:+92-321-741-5373" style="color:#034375;font-weight:bold;font-size:14px">+92-321-7415373</a></strong></span>
    
                <div class="row bannerRow">
                    <div class="col-lg-7 col-md-7 col-sm-7">
                       <div style="height:130px;width:180px;box-sizing:border-box;padding-top:4px">
                            <img style="" src="{{URL::to('public/imgs/logo.png')}}" height="95%" width="90%" style="width: 250px;
                    height: 150px;
                    margin-left: -30px;">
                        </div>
                    <img src="{{URL::to('/public/imgs/app.png')}}" style="position: absolute;
                    height: 35px;
                    left: 285px;
                    top: 69px;"/>
                    </div>
                    <div class="col-lg-5 col-md-5 col-sm-5" style="position:relative">
                    <div style="position:absolute;width:100%;margin-bottom:10px">
                        <img src="{{URL::to('public/imgs/2.png')}}" height="130px" width="142px" style="position:absolute;right:150px;height: 160px;width: 163px;top: -18px;">
                        <img src="{{URL::to('public/imgs/1.png')}}" height="130px" width="142px" style="position:absolute;right:0;height:137px;width:172px;top:-10px">
                    </div>
                    </div>
                </div>
                <ul class="navigation">
                <li><a class="{{(Request::path() == '/' ? 'active' : '')}}" href="{{URL::to('/')}}">Home</a></li>
                <li><a class="{{(Request::path() == 'tetra-pak-machines-expert' ? 'active' : '')}}" href="{{URL::to('tetra-pak-machines-expert')}}">About Us</a></li>
                    <li><a class="{{(Request::path() == 'used-tetra-pak-machines' ? 'active' : '')}}" href="{{URL::to('used-tetra-pak-machines')}}">Used Tetra Pak Machines</a></li>
                <li><a class="{{(Request::path() == 'tetra-pak-spare-parts' ? 'active' : '')}}" href="{{URL::to('tetra-pak-spare-parts')}}" style="position:relative">Tetra Pak Spare Parts <span style="position: absolute;
        top: -1px;
        right: 10px;
        font-size: 10px;
        font-weight: bolder;
        color: #ffdd00;">Online Shop</span> </a></li>
                    <li><a class="{{(Request::path() == 'purchase' ? 'active' : '')}}" href="{{URL::to('purchase')}}">Purchase</a></li>
                    <li><a class="{{(Request::path() == 'Technical-services' ? 'active' : '')}}" href="{{URL::to('Technical-services')}}">Technical Services</a></li>
                <li><a class="{{(Request::path() == 'contact' ? 'active' : '')}}"  href="{{URL::to('contact')}}">Contact Us</a></li>
                <li><a class="{{(Request::path() == 'news' ? 'active' : '')}}" href="{{URL::to('news')}}">News</a></li>
                <li><a href="{{URL::to('cart')}}" style="padding-right:5px;background-color:{{(Request::session()->has('cartData') ?  'maroon' : 'none')}}"><span class="fas fa-shopping-cart"></span> Cart <sup id="totalItems">{{(Request::session()->has("cartData") ? count(Request::session()->get("cartData")) : '')}}</sup> </a></li>
                </ul>
    
                <div style="max-height: 490px;
    min-height: 490px;
    overflow-y: auto;
    overflow-x: hidden;">
                    @yield("content")
                </div>
    
    
    
    
    
    
        </div>
        <div class="divider"></div>
        <div class="footerContainer">
           <span style="color:red;cursor:pointer" onclick="javascript:window.open('https://trepak.pk');">Trepak International</span>
           |
           <a href="#" class="themeAnchor" style="color:#034375;font-weight:bold;font-size:12px"><span>USM-Resale Offers</span></a>
           |
           <span style="color:red">
            Email:
           </span>
           <a href="mailto:info@usedswedenmachines.com" class="themeAnchor" style="color:#034375;font-weight:bold;font-size:12px">info@usedswedenmachines.com</a>
           |
        <a href="{{URL::to('upload-your-machine')}}" class="themeAnchor" style="color:#034375;font-weight:bold;font-size:12px">Upload Your Machine</a>
       <div style="    width: 270px;
        float: right;">
           <ul class="footerSocial">
           <li><a href="https://www.linkedin.com/company/used-sweden-machines" target="_blank" style="background-color:#0077b5" data-toggle="tooltip" title="Linked In"><img src="{{URL::to('/public/imgs/linkedin.svg')}}" style="min-width:15px;max-height:12px"></a></li>
               <li><a href="skype:AREHMANABC?call" target="_blank" data-toggle="tooltip" title="Skype" style="background-color:#00b1f3"><span class="myfa fab fa-skype"></span></a></li>
               <li><a href="https://www.facebook.com/usedswedenmachines/" target="_blank" style="background-color:#3b5998" data-toggle="tooltip" title="Facebook"><span style="display: inline-block;
        margin-left: 3px;" class="fab fa-facebook-f"></span></a></li>
               <li><a href="https://twitter.com/tpusm" target="_blank" style="background-color:#6cdfea" data-toggle="tooltip" title="Twitter"><span class="fab fa-twitter"></span></a></li>
                <li><a href="" style="background-color:#008000" data-toggle="tooltip" title="Message"><img src="{{URL::to('/public/imgs/message.svg')}}" style="    min-width: 15px;
        max-height: 12px;
        height: 120px;
        min-height: 14px;
        margin-top: -4px;"></a></li>
               <li><a href="mailto:info@usedswedenmachines.com" style="background-color:red" data-toggle="tooltip" title="Email"><span class="fas fa-envelope"></span></a></li>
           </ul>
           <div  id="google_translate_element" class="lang" style="margin-top:-2px"></div>
           </div>
           <script>
           function googleTranslateElementInit() {
      new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'ar,de,en,es,fr,ru,pt,fa', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
    }
    </script>
            
        <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
        
    
    
        </div>
    
    
        <div class="global-whatsapp-float">
        <a href="https://api.whatsapp.com/send?phone=923217415373" target="_blank"><img src="{{URL::to('/public/imgs')}}/liveChat.png" style="height:55px"></a>
      
        </div>
        <style>
            body{
                background-color:#ccc;
                font-family:calibri
            }
    
            .global-whatsapp-float {
                position: fixed;
                right: 10px;
                bottom: 44px;
                z-index: 100;
            }
    
            .navigation li a.active{
                background-color: #9e9e9e;
            }
    
            
    
        .titleDiv {
        width: 190px;
        display: none;
        border: 1px solid #ccc;
        background-color: white;
        position: fixed;
        bottom: 200px;
        z-index: 100;
        right: 80px;
        padding: 15px 10px;
        border-radius: 5px;
        box-shadow: 1px 1px 10px -1px #aaa;
    }
    
            .footerSocial li a{
                width:19px;
                max-width:19px;
                
            }
    
    
    
            .MainContainer{
                 background-color:white;
                box-shadow:12px 12px 12px #ccc;
                width:66.25em;
                margin:10px auto;
                box-sizing: border-box;
                padding:6px 13px;
                border:8px solid #ccc;
                border: 3px solid #B7B4B4;
                border-bottom: 3px solid #D3D3D3;
                padding-top: 6px;
                box-shadow: 4px 5px 44px #777;
                margin-top:10px;
                margin-bottom:1px;
            }
    
            .footerSocial{
                list-style-type:none;
                display: inline-block;
        width: 120px;
        background-color: white;
        padding:0;
        float:left;
    
            }
    
            .myfa{
                color:white;
            }
    
            .footerSocial li{
                display:inline-block;
                float:left;
            }
    
            .footerSocial li a{
                display:inline-block;
                padding:0.1px 2px;
                color:white;
            }
    
    
            .bannerRow{
                background:url("{{URL::to('public/imgs/banner1.png')}}") no-repeat;
                background-size:cover;
                margin:0 auto;
                margin-bottom:4px;
    
            }
            .divider{
                height:3px;
            }
            ul.navigation{
                margin:0;
                padding:0;
                list-style-type:none;
                background-color:#034375;
            }
            ul.navigation li{
                display:inline-block;
                margin-left: -4px;
            }
    
            ul.navigation li a{
                display:inline-block;
                padding:0.8em;
                color:white;
                transition:.5s;
                font-size:12.5px;
                padding:0.8em 1em;
            }
            ul.navigation li a:hover{
                text-decoration:none;
                background-color: #9e9e9e;
                color:white;
            }
    
            .footerContainer{
                padding:5px 10px;
                margin-bottom:20px;
                width:66.25em;
                margin:0 auto;
                background-color:white;
                border: 3px solid #B7B4B4;
            }
    
            .themeAnchor{
                font-weight:bolder;
            }
    
            .themeAnchor:hover{
                text-decoration:none;
            }
    
            body{
                font-family:arial;
            }
        </style>
        <script>
            let interval = setInterval(function(){
                
                $(".titleDiv").slideToggle("slow");
                
                
            },30000);
        </script>
    </div>
    <script>
        
        $(window).ready(function(){
            
            $(".page").attr("style","visiblity:visible");
            
            
        })
        
        
    </script>
    <script>
grecaptcha.ready(function() {
    grecaptcha.execute('6LeZq9gUAAAAAEG6mWFXj3o_k0h35O8otcNK7ftL', {action: 'homepage'}).then(function(token) {
      document.getElementById("token").value = token;
    });
});
</script>
</body>
</html>
