@extends("templates.public")
@section("content")
<div style="font-family:arial;font-size:11px">
    <a href="{{URL::to('/')}}" style="">Home</a>&nbsp;»&nbsp;<a href="{{URL::to('/tetra-pak-spare-parts')}}">{{$selectedMachine->title}}</a>&nbsp;»&nbsp;<span>Tetra Pak Machine Spare parts</span>
     <style>
         a{
             color:#034375;
         }
     </style>   
     <input type="text" name="search" id="search" size="50" style="float:right" placeholder="Search by part name or number"> 
 </div>
<div class="row">
    <div class="col-lg-3 col-md-3">
      <form action="{{URL::to('/all-spare-parts')}}" method="get">
        <ul style="padding:0px">
            
            <li class="aside-submenu" id="web">
              <a id="web" class="tag">Select Your Machine Part</a> 
               <select class="show-aside-ul menu12" id="machine_id" required style="width: 100%;padding: 2px;" name="machineId" required="">
                  <option value="">Select Machine</option>

                @foreach($machines as $machine)

               <option value="{{$machine->id}}">{{$machine->title}}</option>

                @endforeach
               </select>
            </li>
            <li class="aside-submenu">
              
              <select class="show-aside-ul" required style="width: 100%;padding: 2px;" name="cat_id" id="category_id" required="">
                <option value="">Select Part Category</option>
                           </select>
            </li>
            <li class="aside-submenu">
      
               <select class="show-aside-ul"  required style="width: 100%;padding: 2px;" id="sub_category" name="subcat_id" required="">
                  <option value="">Select Type</option>
                  
               </select>
            </li>
    
            <li style="background:white; float:right;">
            
           
              <input name="search_part" type="submit" class="news_btn" id="Submit" style="background: #034375;width: 100px;
                height: 28px;
                color: #fff;
                cursor: pointer;
                border-radius: 5px;
                box-shadow: 0 0 20px 0 rgba(0,0,0,.3);" value="Search">
            
            </li>
         </ul>
        </form>
<br/><br/>
         <strong>Machine Parts</strong>
         <div style="max-height:250px;overflow:auto">
                <ul id="myUL">
                <li><a href="{{URL::to('all-spare-parts')}}?machineId={{$machineId}}">All Parts</a></li>
                    @foreach($categories as $cat)
                        <li><span class="myCaret">{{$cat->title}}</span>
                            <ul class="nested">
                                @foreach($subCategories as $subCat)
                                    @if($subCat->parent_id == $cat->id)
                                        <li>
                                        <a href="{{URL::to('all-spare-parts')}}?machineId={{$machineId}}&cat_id={{$cat->id}}&subcat_id={{$subCat->id}}">{{$subCat->title}}</a>
                                        </li>
                                    @endif
                                @endforeach
                            </ul>

                        </li>
                    @endforeach
                </ul>


         </div>

    </div>
    <div class="col-lg-9 col-md-9" style="max-height:450px;overflow:auto;padding-top:10px">
        @if($spareParts != null && count($spareParts) >= 1)

        @foreach($spareParts as $part)

        <article class="line">
            <div class="margin" style="font-family: arial;
    font-size: 13px;">
               <div class="s-12 m-12 l-3 products">
                  <div style=" ">

                    <a href="#" class="fancybox">
                    <img class="imgoffer" src="{{URL::to('/storage/app/products/')}}/{{$part->image}}" style="max-width: 150;
max-height: 100px;border: solid 2px #034375; color:#999999;margin-right:10px" align="left" title="">

                    </a>
                  </div>


               </div>
               <div class="s-12 m-12 l-9">

               <p style="font-size:12px;margin-bottom:0px;">Part Number: {{$part->spare_part_no}}</p>

                  <table>
                    <tbody><tr>
                      <td width="175" style="padding: 0px;border: 0;">
                      <p style="font-weight:bold;font-size:14px;margin-bottom:0px;">{{$part->title}}</p>
                      </td>
                      <td>
                      <p style="font-weight:bold;font-size:14px;margin-bottom:0px;">Price:<span style="color:red;"> {{$part->price}}$</span>
                        </p>
                      </td>
                    </tr>
                    <tr>
                      <td width="175" style="padding: 0px;border: 0;">
                        <p style="margin-bottom:0px;">
                        <strong>Manufacturer :</strong>
                            @php
                                $manufacturer = App\Manufacturer::find($part->manufac);
                                if($manufacturer != null){
                                    echo $manufacturer->title;
                                }
                            @endphp
                        </p>
                      </td>
                      <td>
                        <p style="margin-bottom:0px;">
                        <strong>Delivery Status:</strong>
                        <span style="color:green;">Within 24 hours</span>
                        </p>
                      </td>
                    </tr>
                  </tbody></table>

                  <p class="para" style="height: 47px;margin-bottom:0px;">
                    {{$part->description}}
                 </p>
                  <p align="right" style="margin:0">

                    Quantity <input style="padding:10px;font-weight:bolder;display:inline;cursor:default;" class="numberField" type="number" value="1" min="1" max="1000">


                  <a href="#" onclick="processRequest(this)" data="partNo={{$part->spare_part_no}}&amp;partTitle={{$part->title}}&amp;price={{$part->price}}&amp;status={{$part->ds}}&amp;manu={{($manufacturer != null ? $manufacturer->title : '')}}" style="display:inline-block;border:1px solid #ccc;padding:10px;background-color:maroon;color:white"><span class="fas fa-cart-arrow-down" aria-hidden="true"></span> Add to Basket</a>
                  </p>
                  <br>

                  <hr style="border:0.5px solid gray;margin:0">
               </div>
            </div>
         </article>

        @endforeach

        @else

            <div class="alert alert-danger">
                No Spare Part Founded regarding this category
            </div>

        @endif
    </div>

</div>

<style>
    ul{
        list-style-type:none;
    }

    .tag{
        display: block;
        background-color: gray;
        color: white;
        padding: 5px;
        margin: 5px 0px 2px;
    }

    .tag:hover{
        color:white;
        text-decoration:none;
        cursor:default;
    }

    ul.machinesView{
        margin-top:30px;
    }

    ul.machinesView li{
        width:80px;
        height:100px;
        float:left;
        margin-right:30px;

    }
    ul.machinesView li img{
        max-width:50px;
    }

    ul.machinesView li a{
        color:black;
    }

    ul.machinesView li a:hover{
        text-decoration:none;
    }

    ul.machinesView li strong{
        font-weight:bolder;
        font-size:14px;
    }

    /*tree view coding start*/

    /* Remove default bullets */
ul, #myUL {
  list-style-type: none;
}

/* Remove margins and padding from the parent ul */
#myUL {
  margin: 0;
  padding: 0;
}

/* Style the caret/arrow */
.myCaret {
  cursor: pointer;
  user-select: none; /* Prevent text selection */
}

/* Create the caret/arrow with a unicode, and style it */
.myCaret::before {
  content: "\25B6";
  color: black;
  display: inline-block;
  margin-right: 6px;
}

/* Rotate the caret/arrow icon when clicked on (using JavaScript) */
.caret-down::before {
  transform: rotate(90deg);
}

/* Hide the nested list */
.nested {
  display: none;
}

#myUL li{
    width:100%;
}

#myUL li a{
    width:100%;
}

/* Show the nested list when the user clicks on the caret/arrow (with JavaScript) */
.active {
  display: block;
}


    /*tree view coding end*/
</style>
<script>
    var toggler = document.getElementsByClassName("myCaret");
var i;

for (i = 0; i < toggler.length; i++) {
  toggler[i].addEventListener("click", function() {
    this.parentElement.querySelector(".nested").classList.toggle("active");
    this.classList.toggle("caret-down");
  });
}

function processRequest(cartButton){

    let partData = cartButton.getAttribute("data");
    let previousInnerHTML = cartButton.innerHTML;
    var quantity = cartButton.parentNode.children[0].value;
    partData += "&quantity=" + quantity;
    cartButton.innerHTML = "Please Wait... ";

    $.ajax({
        url:"{{URL::to('/api/fillCart')}}",
        method:"GET",
        data:partData,
        success:function(data){
            cartButton.innerHTML = "Added";
            cartButton.setAttribute("disabled","true");
            $("#totalItems").html(data);



        }


    })



}
</script>
<script>
  $("#machine_id").on("change",function(){
    let machineId = $(this).val();
    $.ajax({
        url:"{{URL::to('/api/getPartsCategories')}}/" + machineId,
        method:"GET",
        success:function(response){
            let categories = response;
            $("#category_id").html("<option value=''>Select Categories</option>");
            categories.map(category => {
                $("#category_id").append("<option value='"+category.id+"'>"+category.title+"</option>");
            })

        }
    })
  });

  $("#category_id").on("change",function(){

      let category_id = $(this).val();
      $.ajax({
          url:"{{URL::to('/api/getSubCategory')}}/" + category_id,
          method:"GET",
          success:function(response){
             $("#sub_category").html("<option value=''>Select Sub Category</option>");
             response.map(data => {
                 $("#sub_category").append("<option value='"+data.id+"'>"+data.title+"</option>")
             })
          }
      })

  });

</script>
@endsection
