@extends("templates.public")

@section("content")

<div style="font-family:arial;font-size:11px">

   <a href="{{URL::to('/')}}" style="">Home</a>&nbsp;»&nbsp;<a href="{{URL::to('/news')}}">News</a>

    <style>

        a{

            color:#034375;

        }

    </style>    

</div>

<div class="row">

    <div class="col-lg-4 col-md-4">

        <ul class="news">

        <li><a href="{{URL::to('/news')}}" class="{{($mode=='news' ? 'active' : '')}}">News</a></li>

            <li><a href="{{URL::to('/news?news_type=events')}}" class="{{($mode=='events' ? 'active' : '')}}">Events</a></li>

            <li><a href="{{URL::to('/news?news_type=newsletter')}}" class="{{($mode=='newsletter' ? 'active' : '')}}">Newsletters</a></li>

        <li><a href="{{URL::to('/news?news_type=testimonials')}}" class="{{($mode=='testimonials' ? 'active' : '')}}">Testimonials</a></li>

        <li><a href="{{URL::to('/news?news_type=references')}}" class="{{($mode=='references' ? 'active' : '')}}">Referencess</a></li>

        </ul>

        <p>

            Please register in the area below to receiver our newsletter. In the news section you will find a lot of interesting information about our company and the trade in general (Information) as well as the newsletter archive

        </p>

        <form method="post" action="">

            <table border="0" class="newsletterform">

              <tbody><tr>
                <input type="hidden" name="_token" vaule="{{csrf_token()}}">
                <td style="border: none;">

                  <input type="email" name="email" maxlength="255" width="160px" required="required" placeholder="Enter your Email"><br>

                </td>

                <td valign="top" style="border: none;">

                  <input type="submit" class="news_btn" id="Submit" style="background: #034375;width: 100px;

              height: 28px;

              color: #fff;

              cursor: pointer;

              border-radius: 5px;

              box-shadow: 0 0 20px 0 rgba(0,0,0,.3);" value="Subscribe"/>

                </td>

              </tr>
              <tr>
                <td colspan="2">
                     @if(!empty($message))
                     {{$message}}
                    @endif
                </td>
              </tr>

            </tbody></table>

          </form>
            
          <br/><br/>

    </div>

    <div class="col-lg-8 col-md-8" style="max-height:465px;overflow:auto">

       <br/>

        @if($mode == "news")



            @foreach($data as $news)

                

                <div class="row">

                    <div class="col-lg-2 col-md-2">

                    <img src="{{($news->image == null ? URL::to('/public/imgs/newsletter-icon.png') : URL::to('/storage/app/products/') . '/' . $news->image)}}" alt="" class="img-thumbnail" style="min-width:100%;min-height:100%;max-width:100%;max-height:100%">

                    </div>

                    <div class="col-lg-10 col-md-10">

                        <span>{{$news->news_date}}</span><br/>

                        <strong>{{$news->news_title}}</strong>

                        <br/><br/>

                    <a href="{{URL::to('/news/')}}/{{$news->id}}">Read More</a>

                    </div>

                </div>

                <hr/>



            @endforeach



        @endif

        @if($mode == "newsletter")



        @foreach($data as $news)

                

        <div class="row">

            <div class="col-lg-2 col-md-2">

            <img src="{{URL::to('/public/imgs/letter.png')}}" alt="" class="img-thumbnail" style="min-width:100%;min-height:100%;max-width:100%;max-height:100%">

            </div>

            <div class="col-lg-10 col-md-10">

                <span>{{$news->temp_title}}</span><br/>

            <a href="{{URL::to('news/newsletter/')}}/{{$news->id}}">View Complete Newsletter</a>

            </div>

        </div>

        <hr/>



    @endforeach



        @endif

        @if($mode == "testimonials")

        @foreach($data as $news)

        <div class="row">

            <div class="col-lg-3 col-md-3">

            <img src="{{URL::to('/storage/app/') . '/' . $news->brandLogo}}" alt=""  style="width: 130px;
            height: 110px;
            color: #999999;
            border: solid 2px #034375;">

            </div>

            <div class="col-lg-9 col-md-9" style="font-family:arial">

                <div class="s-9 m-9 l-9">

                    <p style="font-size:12px;font-weight:bolder;display:block;margin-bottom:0px">

                      

                    <span style="float:left;color:green">

                     {{$news->companyName}}  </span>

                    <span style="float:right">

                     {{$news->sentDate}}                                   </span>

                    <br>

                    </p>

                    <p class="para" style="height: 60px;text-align: justify;">

                    {{$news->testimonial}}

                     </p>

                   

                    <p style="margin-top:20px;font-size:12px;font-weight:bolder;">



                    <span style="float:left">Sent By {{$news->personName}} , {{$news->personDesignation}} at {{$news->companyName}}</span>

                    </p>

          

                 </div>

            </div>

        </div>

        <hr/>

        @endforeach

        @endif

        @if($mode == "references")

            @foreach($data as $news)

            <div class="row">

               

                <div class="col-lg-12 col-md-12">

                    <table cellpadding="10" style="border:none;font-family:arial;font-size:12px">

                    <tbody><tr><th style="border-right:none;">Company Name</th><td style="border-right:none;color:green;font-weight:bolder;width:80%" colspan="2">{{$news->customerName}}</td>

                        </tr><tr>

                        

                        </tr><tr><th style="border-right:none">Delivery Scope</th><td colspan="3" style="border-right:none">{{$news->deliveryScope}}</td></tr>

                        <tr>

                          <th style="border-right:none">Project Status</th>

                          <td colspan="3" style="border-right:none">

                            {{$news->projectStatus}}

                        </td>

                        </tr>

                        <tr>

                                                          <th style="border-right:none;min-width:120px">Contact Person</th>

                        <td style="border-right:none">

                        {{$news->contactPerson}}

                        </td>

                        </tr>



                    </tbody></table>

                </div>

            </div>

            <hr/>

            @endforeach

        @endif

        @if($mode == "events")

            

         @foreach($data as $event)

                

                <div class="row">

                    <div class="col-lg-2 col-md-2">

                    <img src="{{URL::to('/storage/app/event/') . '/' . $event->featuredImage}}" alt="" class="img-thumbnail" style="min-width:100%;min-height:100%;max-width:100%;max-height:100%">

                    </div>

                    <div class="col-lg-10 col-md-10">

                    <strong>{{$event->dateofevent}}</strong><br/>

                        <span>{{$event->eventName}}</span><br/>

                        

                    <a href="{{URL::to('/news/event/')}}/{{$event->eventId}}">Read More</a>

                    </div>

                </div>

                <hr/>



            @endforeach

        

        @endif

    </div>

</div>



<style>

    body{

        font-family:arial;

        

    }

ul{

    list-style-type:none;

    margin:0;

    padding:0;

    width:100%;

    background-color:#f4f4f4;

}



ul li{

    display:block;

}



ul li a{

    display:block;

    padding:10px 20px;

    color:black;

}



ul li a:hover{

    background-color:#ccc;

    color:white;

    text-decoration:none;

}



ul li a.active{

    background-color:#ccc;

    color:white;

}



.img-thumbnail{

    border:none;

}





</style>



@endsection