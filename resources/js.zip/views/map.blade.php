@extends("templates.public")
@section("content")
    <h3>Testing</h3>

@endsection