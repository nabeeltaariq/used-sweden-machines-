@extends("templates.public")
@section("content")
<br/>
<h3 class="item" style="
font-weight:bold;
 display: block;
 font-family: 'arial';
 display:inline-block;
 font-size:14px;
 background: #b43720;
 background: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/Pgo8c3ZnIHhtbG5zPSJod…IgaGVpZ2h0PSIxIiBmaWxsPSJ1cmwoI2dyYWQtdWNnZy1nZW5lcmF0ZWQpIiAvPgo8L3N2Zz4=);
 background: -moz-linear-gradient(90deg, #b43720 0%, #e94541 100%);
 background: -webkit-gradient(linear, left bottom, right top, color-stop(0%,#b43720), color-stop(100%,#e94541));
 background: -webkit-linear-gradient(90deg, #b43720 0%,#e94541100%);
 background: -o-linear-gradient(90deg, #b43720 0%,#e94541 100%);
 background: -ms-linear-gradient(90deg, #b43720 0%,#e94541 100%);
 background: linear-gradient(90deg, #FBCA01 0%,#FBCA01 100%);
 filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b43720', endColorstr='#e94541',GradientType=1 );

 color: #034b84;

 line-height: 30px;
 padding: 0px 14px;
 position: relative;
 margin-top:0px">Upload Your Machine</h3>
 @if(isset($message))
<div class="alert alert-success">
    Success! Your machine has been successfully uploaded, please wait it will take time to approve from  our administation to display on the used tetra pack machines , you will get confirmation email from our administration.
</div>

 @endif


 <form action="" method="post" enctype="multipart/form-data">
    <table border="0" cellpadding="0" cellspacing="0" style="background: none repeat scroll 0 0 rgba(53, 147, 175, 0.06);width:100%">
        <tbody>
        <!-- <tr>
          <td width="110" height="22" align="left" valign="top"><div align="left"><span class="kontakt-form-text">Title</span><span class="kontakt-info">*</span><span class="kontakt-form-text">:</span> </div></td>
          <td width="30" height="22" align="center" valign="middle"></td>
        <td height="22" align="left" valign="top"><input name="title" type="radio" class="kontakt-form-text" value="Mrs" >
              <span class="kontakt-form-text">Mrs.</span>
              <input name="title" type="radio" class="kontakt-form-text" value="Mr">
              <span class="kontakt-form-text">Mr.</span> </td>
        </tr> -->
        <tr style="background-color: #f3f9fa">
          <td width="110" height="22" align="left" valign="top" style="border-right:1px solid #ccc"><div align="left"><span class="kontakt-form-text">Company</span><span class="kontakt-form-text"> :</span> </div></td>
          <td width="30" height="22" align="center" valign="middle"></td>
        <td height="22" align="left" valign="top"><label for="textfield"></label>
              <input name="company" type="text" class="kontakt-text" id="company" style="width:80%;margin-bottom:2px" value=""></td>
        </tr>
        <tr style="background-color:white">
          <td width="110" height="22" align="left" valign="top" style="border-right:1px solid #ccc"><div align="left"><span class="kontakt-form-text">Name</span><span class="kontakt-info">*</span><span class="kontakt-form-text">:</span> </div></td>
          <td width="30" height="22" align="center" valign="middle"></td>
          <td height="22" align="left" valign="top">&nbsp;<input name="name" type="text" class="kontakt-text" id="name" style="width:80.0%;margin-bottom:2px" value="" required="required"></td>
        </tr>
        <!-- <tr>
          <td width="110" height="22" align="left" valign="top"><div align="left"><span class="kontakt-form-text">First Name</span><span class="kontakt-form-text"> :</span> </div></td>
          <td width="30" height="22">&nbsp;</td>
          <td height="22" align="left" valign="top"><input name="fname" type="text" class="kontakt-text" id="fname" size="30" value=""></td>
        </tr> -->
        <tr style="background-color: #f3f9fa;">
          <td width="110" height="22" align="left" valign="top" style="border-right:1px solid #ccc"><div align="left"><span class="kontakt-form-text">Phone :</span> </div></td>

          <td width="30" height="22">&nbsp;</td>
          <td height="22" align="left" valign="top">&nbsp;<input name="phone" type="text" class="kontakt-text" id="phone" style="width:80.0%;margin-bottom:2px" value=""></td>
        </tr>
        <tr style="background-color:white">
          <td width="110" height="22" align="left" valign="top" style="border-right:1px solid #ccc"><div align="left"><span class="kontakt-form-text">E-Mail</span><span class="kontakt-info">*</span><span class="kontakt-form-text">: </span></div></td>
          <td width="30" height="22" align="center" valign="middle"></td>
          <td height="22" align="left" valign="top">&nbsp;<input name="email" type="email" class="kontakt-text" id="email" style="width:80.0%;margin-bottom:2px" value="" required="required"></td>
        </tr>
        
        <tr style="background-color: #f3f9fa;">
            <td width="110" height="" align="left" valign="top" style="border-right:1px solid #ccc"><div align="left"><span class="kontakt-form-text">Machine Name</span><span class="kontakt-info">*</span><span class="kontakt-form-text">:</span></div></td>
            <td width="30" height="" align="center" valign="top"></td>
             <td height="" align="left" valign="top"><label for="textarea"></label>
            <input type="text" name="machineName" id="machineName" style="width:80%">
          </tr>


        <tr style="background-color: white;">
            <td width="110" height="" align="left" valign="top" style="border-right:1px solid #ccc"><div align="left"><span class="kontakt-form-text">Technical Secifications</span><span class="kontakt-info">*</span><span class="kontakt-form-text">:</span></div></td>
            <td width="30" height="" align="center" valign="top"></td>
             <td height="" align="left" valign="top"><label for="textarea"></label>
             <textarea style="width:80%" name="technicalSpecifications" requied></textarea>
          </tr>

       <input type="hidden" name="country" value="none">
        <tr style="background-color: #f3f9fa;">
          <td width="110" height="" align="left" valign="top" style="border-right:1px solid #ccc"><div align="left"><span class="kontakt-form-text">Machine Featured Image</span><span class="kontakt-info">*</span><span class="kontakt-form-text">:</span></div></td>
          <td width="30" height="" align="center" valign="top"></td>
      <td height="" align="left" valign="top"><label for="textarea"></label>
            <input type="file" name="featuredImage" id="featuredImage">
        </tr>
        <tr style="background-color: white;">
            <td width="110" height="" align="left" valign="top" style="border-right:1px solid #ccc"><div align="left"><span class="kontakt-form-text">Machine Other Image</span><span class="kontakt-info">*</span><span class="kontakt-form-text">:</span></div></td>
            <td width="30" height="" align="center" valign="top"></td>
        <td height="" align="left" valign="top"><label for="textarea"></label>
              <input type="file" name="otherImages[]" id="otherImages" multiple>
              <Br/><br/>
          </tr>

          
        <input type="hidden" name="_token" value="{{csrf_token()}}">
        <tr align="left" valign="bottom">
          <td width="110" align="left" valign="top"><input type="hidden" name="ueberpruefung" value="1"><input type="hidden" name="ID" value=""></td>
          <td width="30">&nbsp;</td>
        <td valign="middle"><label for="Submit"></label>
              <input name="contactformnew" type="submit" class="kontakt_btn" id="Submit" value="Submit">
              <span class="kontakt-info">*</span><span class="kontakt-form-text">Required</span>
              <span class="kontakt-info">*</span><span class="kontakt-form-text">Please write English if possible!</span>                      </td>
          </tr>
        </tbody>
      </table>

 </form>


@endsection
