@extends("templates.public")
@section("content")
<div style="font-family:arial;font-size:11px">
    <a href="{{URL::to('/')}}" style="">Home</a>&nbsp;»&nbsp;<span>Products</span></span>
     <style>
         a{
             color:#034375;
         }

        
     </style>    
 </div>
    <div class="row" style="margin:0px 1px;margin-top:10px" ng-app="myModule" ng-controller="myController">
    
        <div class="col-lg-3 col-md-3" style="background-color:#f4f4f4;max-height: 465px;overflow: auto;box-sizing:border-box;padding-bottom:25px;">
            <ul class="leftSidebar">
                <li>
                    <a href="#" id="*" class="{{($selectedCat == '*' ? 'selected' : '')}}" ng-click="changeCat('*')">» All Machines</a>
                    
                </li>
                @foreach($allCatagories as $catagory)

                    <li>
                        <a href="#" class="{{($selectedCat == $catagory->id ? 'selected' : '')}}" id="{{$catagory->id}}" ng-click="changeCat({{$catagory->id}})">
                            » {{$catagory->name}}
                        </a>
                    </li>

                    @endforeach
            </ul>
        </div>
        <div class="col-lg-9 col-md-9" style="padding:0px;position:relative">

            <input type="text" name="search" id="search" size="50" ng-model="search" placeholder="Search By Machine Name or SKU" style="
    position: absolute;
    top: -25px;
    right: 0px;
    z-index: 500;
    border-top:none;
    border-left:none;
    border-right:none;
    font-family:arial;
    font-size:12px;
    outline:none
">

            <div class="display">
                <p align="center"  style="margin:0">
                    
                        {{-- <input type="text" class="form-control" ng-model="search" placeholder="Type name or SKU number to search...."> --}}
                    <span ng-if="loading">
                        <img src="{{URL::to('/public/imgs/loader.gif')}}" style="margin-top:200px" height="50px" width="50px">
                    </span>
                    <span id="loader">
                        <img src="{{URL::to('/public/imgs/loader.gif')}}" style="margin-top:200px" height="50px" width="50px">
                    </span>
                    
                </p>
                <div ng-show="!loading">


                        <div ng-repeat="machine in machines|filter:search" style="width:100%;margin-bottom:5px;min-height:100px" repeat-done="finished()" ng-cloak>
                           
                           <div class="row">
                               <div class="col-lg-2 col-md-2">
                                    <div style="width:100%;height:100px;max-height:100px;float:left;position:relative">
                                    <img src="{{URL::to('/public/imgs/soldLogo.png')}}" ng-if="machine.s_status.toUpperCase().indexOf('sold'.toUpperCase()) != -1" alt="" style="position:absolute;left:10px;top:0">
        
                                    <img src="{{URL::to('/storage/app/products/')}}/<%machine.image%>" style="max-height:100px;min-height:100px;max-width:144px;min-width:90px;margin-left:10px;border:solid 2px #034375;"/>
        
                                    </div>
                               </div>
                               <div class="col-lg-10 col-md-10">
                                   <div class="description" style="width:100%;margin-left:50px;min-height:100px;max-height:100px;border-top:1px solid gray;box-sizing:border-box;">
                                    <p style="font-size:12px;line-height:1.4;margin:0;margin-top:3px">item #: <%machine.SKU%></p> 
                                    <p style="font-weight:bold;line-height:1.4;font-size:13px;margin:0;max-width:460px" onclick="getLocation('machine.php?m_id=102')"><a class="link" style="color:black;font-family:arial;text-decoration:none" href="{{URL::to('/')}}/<%machine.url%>"><%machine.pr_title%></a></a></p>
                                    <p style="font-family:arial;font-size:13px;max-width:460px"><%machine.short_des.substr(0,190)%><a style="color:black" onclick="getLocation('machine.php?m_id=102')" href="{{URL::to('/')}}/<%machine.url%>"><strong>»&nbsp;More details</strong></a></p>
                                   
                                    </div>
                               </div>
                           </div>


                           
                        </div>


                    <div>


                    </div>
                </div>
            </div>
        </div>
    </div>
    <style>
        .leftSidebar{
            list-style-type:none;
            margin:0;
            padding:0;
            font-family:arial;
            font-size:13px;
        }

        .leftSidebar li a.selected{
            color:gray;
        }

        hr{
            padding:0px;
            margin:0;
            border:0.5px solid gray;
        }

        .leftSidebar li{
            display:block;
        }

        .display{
            height:465px;
            max-height:465px;
            overflow-x:hidden;
            overflow-y:auto;
            position:relative;
            margin-top: 0px;
        }

        .leftSidebar li a{
            display:block;
            text-decoration:none;
            color:black;
            font-weight:bolder;
            padding:3px 0px;
        }

        .leftSidebar li a:hover{
            color:gray;
        }

        .para{
            font-family:arial;
            font-size:13px;
        }
        
    </style>
    <script>
        let myModule = angular.module("myModule",[],$interpolateProvider => {

            $interpolateProvider.startSymbol("<%");
            $interpolateProvider.endSymbol("%>");


        });
        myModule.controller("myController",($scope,$http) => {
           $scope.machines = [];
           $scope.loadig = true;

            $scope.arrangeBySold = function(){
              let data =  $scope.machines;
              let soldData = $scope.machines.filter(machine => machine.s_status.toUpperCase().indexOf("sold".toUpperCase()) != -1);
              let unsoldData = $scope.machines.filter(machine => machine.s_status.toUpperCase().indexOf("sold".toUpperCase()) == -1)
             $scope.machines = [...unsoldData,...soldData];
            }

            <?php 
                $url = "";
                if(Request::session()->get("selectedCat") == "*"){
                    $url = URL::to('/api/fetchMachines');
                }else{
                    $url = URL::to('/api/fetchMachines') . "/" . Request::session()->get("selectedCat");
                }
            ?>

                $http({
                    "url":"{{$url}}",
                    "method":"POST"
                }).then(response => {

                    $scope.machines = response.data;

                    for(i = 0;i<$scope.machines.length;i++){
                        let title = $scope.machines[i].pr_title;
                        title = title.replace("®",'');
                        let titleToken = title.split(' ');
                        let url = titleToken.join('-');
                        $scope.machines[i].url = url;
                    }

                    $scope.loading = false;
                    $scope.arrangeBySold();
                    $("#loader").hide();
                });

                

                $scope.changeCat = id => {
                    $scope.machines = [];
                    $scope.loading = true;
                    let uri = "";
                    if(id != '*'){
                        uri = "{{URL::to('/api/fetchMachines') . '/'}}" + id;
                    }else{
                        uri = "{{URL::to('/api/fetchMachines')}}";
                    }
                    $http({
                    "url":uri,
                    "method":"POST"
                    }).then(response => {
                        console.log("From response ");
                        console.log(response.data);
                        $scope.machines.splice(0,$scope.machines.length);
                        $scope.machines = response.data;
                        for(i = 0;i<$scope.machines.length;i++){
                        let title = $scope.machines[i].pr_title;
                        title = title.replace("®",'');
                        let titleToken = title.split(' ');
                        let url = titleToken.join('-');
                        $scope.machines[i].url = url;
                        }

                        $scope.loading = false;
                        $scope.arrangeBySold();
                    });
                }
        });


        //change selection script on clicking on left sidebarmenu
        $(".leftSidebar li a").on("click",function(){

          $(".leftSidebar li a").each(function(i,element){
              element.removeAttribute("class");
          });
            
          $(this).attr("class","selected");

        });
    </script>
    <style>
        
    </style>
@endsection
