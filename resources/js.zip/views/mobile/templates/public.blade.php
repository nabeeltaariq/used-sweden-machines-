<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>USED SWEDEN MACHINES</title>
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/6ba88d1a21.js" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
<script src="https://www.google.com/recaptcha/api.js?render=6LeZq9gUAAAAAEG6mWFXj3o_k0h35O8otcNK7ftL"></script>
</head>
<body>
    <div style="position:fixed;left:0;right:0;top:0;z-index:200">
        <div class="container-fluid" style="background-color:#015292"><p style="margin:0px;color:white;font-weight:bolder;font-family:arial;font-size:12px" align="center">Best Supplier Of Refurbished Tetra Pak Machines</p></div>

        <div class="container" style="background-color:white">
        <div style="width:30%;float:left;margin-top:10px"><img onclick="javascript:window.location='{{URL::to('/')}}';" src="{{URL::to('/public/imgs/usm.svg')}}" height="90px"></div>
                <div style="width:70%;float:left;font-size:12px;padding-top:10px;padding-left:20px">
                    <a href="tel:+92-321-741-5373" style="color:red;line-height:2.5;font-weight:bolder"> Call USM: </a>
                    <span style=""><a href="tel:+92-321-741-5373" style="color:#0b4692;">+92-321-741-5373</a></span>
                    <br>
                    <span><a href="mailto:info@usedswedenmachines.com" style="color:#0b4692;">info@usedswedenmachines.com</a> </span><br>

                    <span><a href="https://trepak.pk" target="_blank" style="color:#0b4692;">Trepak International</a></span><br>
                    <!--
                    <span><a href="#" style="color:#0b4692;">e-Business</a></span> -->
                </div>
                <div style="clear:both"></div>

        </div>
        <div style="margin-top: 0px;background-color: #e7e7ec;padding: 10px 0px;">

            <input type="text" name="search" autocomplete="Off" placeholder="Search In USM" class="form-control" style="width:80%;float:left;border-radius:0px;margin-left:5px">
                <span class="fas fa-bars toggleButton" style="font-size:28px;margin-left:20px;color:#015291;display: inline-block;margin-top: 3px;"></span>

            </div>
            <div class="menu" style="text-align: right;">

                <ul class="menuProducts">

                <li><a href="{{URL::to('/')}}">Used Tetra Pak Machines</a></li>
                <li><a href="{{URL::to('/tetra-pak-spare-parts')}}">Tetra Pak Machines Spare Parts</a></li>
                <li><a href="{{URL::to('/purchase')}}">Sell Your Machines To USM</a></li>
                <li><a href="{{URL::to('/Technical-services')}}">Technical Services</a></li>
                <li><a href="{{URL::to('/contact')}}">Contact us</a></li>
                  <li><a href="tel:+92-321-741-5373" style="text-align: center;background-color: #404040;font-weight:bolder;">Call USM: +92-321-741-5373</a></li>

                </ul>

            </div>
    </div>

    </div>
<style>
.menu{
    display:none;
}


.menuProducts{
    list-style-type: none;
    margin:0;
    padding:0;
}

.menuProducts li{
    display:block;
}

.menuProducts li a{
    display:block;
    padding:6px 2px;
    border-bottom: 0.08px solid #989797;
    background-color:#015292;
    color:white;
    font-weight:boler;
}

</style>
<!--every page content -->
<div class="content" style="margin-top:170px;min-height:250px">
   @yield("content")
</div>
<!-- end of every page content -->
<div class="footer">
    <h2 style="margin:0px;float:left">Contact</h2>
    <p style="float:right">
    <a href="https://www.facebook.com/Used-Sweden-Machines-1422520224715742/" target="_blank">
            <i class="fab fa-facebook-square socialFa"></i>
        </a>
        <a href="https://www.linkedin.com/in/used-sweden-machines-a9b812a1" target="_blank">
            <i class="fab fa-linkedin socialFa"></i>
        </a>
    </p>
    <div style="clear:both"></div>
    <br>
    <p style="font-size:16px;">
        The management team of <br>
        Used Sweden Machines
    </p>
    <p style="font-size:16px;">
            83-A, S.I.E # 1,<br>
        Gujranwala Pakistan
        <br>
        Tel.: +92 (321) 7415373
    </p>
    <p>

        <a href="tel:+92-321-741-5373" class="footerButton"><i class="fas fa-phone-square"></i> Call</a>
        <br>

    </p>
</div>




<style>
    .footer{
        width: 100%;
        background-color: #015291;
        padding: 10px 10px;
        color: white;
    }

    .socialFa{
        font-size: 34px;
    color: white;
    display: inline-block;
    margin-right: 10px;
    }

    .footerButton{
        display: inline-block;
    width: 260px;
    height: 50px;
    background: linear-gradient(#FFFFFF, #d9e1ea);
    box-sizing: border-box;
    padding: 10px 8px;
    font-weight: bolder;
    font-size: 24px;
    color: #1e5b90;
    margin-top: 10px;
    }
    .helpChat{
        width: 100%;
    padding: 10px 10px;
    position: fixed;
    bottom: 0;
    z-index: 200;
    }
</style>
<script>
    $(".toggleButton").click(function(){

        $(".menu").slideToggle("slow");

    })

</script>

<div class="helpChat">
    <p style="margin:0;padding:0;" align="right">
     <a href="https://api.whatsapp.com/send?phone=923217415373" target="_blank">
         <img src="https://usedswedenmachines.com/img/liveChat.png" style="height:60px">
     </a>
   </p>
</div>
</body>
</html>
