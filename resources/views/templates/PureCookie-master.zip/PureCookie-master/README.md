# PureCookie
Lightweight Cookie-Consent with vanilla Javascript.
