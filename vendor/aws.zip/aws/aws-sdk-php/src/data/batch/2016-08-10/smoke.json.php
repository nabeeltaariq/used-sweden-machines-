<?php
// This file was auto-generated from sdk-root/src/data/batch/2016-08-10/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'DescribeComputeEnvironments', 'input' => [], 'errorExpectedFromService' => false, ], ],];
