<?php
// This file was auto-generated from sdk-root/src/data/braket/2019-09-01/paginators-1.json
return [ 'pagination' => [ 'SearchDevices' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'devices', ], 'SearchQuantumTasks' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'quantumTasks', ], ],];
